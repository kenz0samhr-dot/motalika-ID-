# Mortalika Free Edition

Proyecto Next.js gratuito para identificar motocicletas mediante imagen.
