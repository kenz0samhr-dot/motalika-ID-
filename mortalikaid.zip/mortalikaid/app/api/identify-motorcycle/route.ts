import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { image } = await req.json();

    const mockData = {
      name: "Honda CB500F",
      brand: "Honda",
      model: "CB500F",
      year: "2021",
      description: "Motocicleta naked de media cilindrada, ideal para uso urbano y práctico.",
      price: "$6,500 USD",
      products: [
        { name: "Casco Integral", price: "$150", description: "Casco de protección completo." },
        { name: "Guantes", price: "$50", description: "Guantes resistentes para motociclistas." }
      ]
    };

    return NextResponse.json(mockData);
  } catch (error) {
    return NextResponse.json({ error: "Error al procesar imagen" }, { status: 500 });
  }
}
