import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { image } = await request.json()

    if (!image) {
      return NextResponse.json({ error: "No se proporcionó ninguna imagen" }, { status: 400 })
    }

    const apiKey = process.env.GOOGLE_GEMINI_API_KEY
    if (!apiKey) {
      return NextResponse.json(
        {
          error:
            "API key de Google Gemini no configurada. Por favor, añade GOOGLE_GEMINI_API_KEY en las variables de entorno.",
        },
        { status: 500 },
      )
    }

    const base64Data = image.split(",")[1] || image

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash-lite:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `Identifica esta motocicleta y proporciona información detallada incluyendo productos relacionados con sus precios.

Proporciona la información en formato JSON estricto:
{
  "name": "Nombre completo de la moto",
  "brand": "Marca",
  "model": "Modelo",
  "year": "Año (o rango de años si no estás seguro)",
  "description": "Descripción breve de 2-3 líneas sobre las características principales de esta moto",
  "price": "Precio aproximado en USD (formato: $XX,XXX)",
  "products": [
    {
      "name": "Nombre del producto o accesorio",
      "price": "Precio en USD (formato: $XXX)",
      "description": "Breve descripción del producto"
    }
  ]
}

Para "products", incluye 3-5 productos o accesorios comunes para esta moto específica, como:
- Piezas de repuesto originales
- Accesorios de rendimiento
- Equipamiento de protección compatible
- Productos de mantenimiento especializados
- Mejoras o modificaciones populares

Si no puedes identificar con certeza algún campo, proporciona tu mejor estimación basada en las características visibles. 
Responde SOLO con el objeto JSON, sin texto adicional. Todo en español.`,
                },
                {
                  inline_data: {
                    mime_type: "image/jpeg",
                    data: base64Data,
                  },
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.4,
            topK: 32,
            topP: 1,
            maxOutputTokens: 2048,
          },
        }),
      },
    )

    if (!response.ok) {
      const errorData = await response.json()

      const errorMessage = errorData.error?.message || "Unknown error"
      if (errorData.error?.code === 429) {
        return NextResponse.json(
          {
            error:
              "Límite de cuota excedido. Por favor, espera unos momentos e intenta de nuevo. Si el problema persiste, verifica tu plan de Google Gemini API en https://ai.google.dev/",
          },
          { status: 429 },
        )
      }

      return NextResponse.json({ error: "Error al comunicarse con Google Gemini: " + errorMessage }, { status: 500 })
    }

    const data = await response.json()

    const textContent = data.candidates?.[0]?.content?.parts?.[0]?.text

    if (!textContent) {
      return NextResponse.json({ error: "No se pudo obtener información de la imagen" }, { status: 500 })
    }

    let jsonText = textContent.trim()
    if (jsonText.startsWith("```json")) {
      jsonText = jsonText.replace(/```json\n?/g, "").replace(/```\n?/g, "")
    } else if (jsonText.startsWith("```")) {
      jsonText = jsonText.replace(/```\n?/g, "")
    }

    const motorcycleInfo = JSON.parse(jsonText)

    return NextResponse.json(motorcycleInfo)
  } catch (error) {
    console.error("[v0] Error processing request:", error)
    return NextResponse.json(
      { error: "Error al procesar la solicitud: " + (error instanceof Error ? error.message : "Unknown error") },
      { status: 500 },
    )
  }
}
