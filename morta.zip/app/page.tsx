"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, Bike, Loader2, DollarSign, Camera, Package } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface MotorcycleInfo {
  name: string
  brand: string
  model: string
  year: string
  description: string
  price: string
  products?: Array<{
    name: string
    price: string
    description: string
  }>
}

export default function Home() {
  const [image, setImage] = useState<string | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [motorcycleInfo, setMotorcycleInfo] = useState<MotorcycleInfo | null>(null)
  const [showPrice, setShowPrice] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isCameraOpen, setIsCameraOpen] = useState(false)
  const streamRef = useRef<MediaStream | null>(null)

  const analyzeImage = async (base64Image: string) => {
    setIsAnalyzing(true)
    try {
      const response = await fetch("/api/identify-motorcycle", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ image: base64Image }),
      })

      const data = await response.json()

      if (!response.ok || data.error) {
        const errorMessage = data.error || "Error desconocido al identificar la moto"
        alert(errorMessage)
        setIsAnalyzing(false)
        return
      }

      setMotorcycleInfo(data)
    } catch (error) {
      console.error("Error analyzing image:", error)
      alert("Error de conexión al procesar la imagen. Por favor, verifica tu conexión e intenta de nuevo.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  const handleImageUpload = async (file: File) => {
    const reader = new FileReader()
    reader.onload = async (e) => {
      const base64Image = e.target?.result as string
      setImage(base64Image)
      setMotorcycleInfo(null)
      setShowPrice(false)
    }
    reader.readAsDataURL(file)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("image/")) {
      handleImageUpload(file)
    }
  }

  const openCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
      setIsCameraOpen(true)
    } catch (error) {
      console.error("Error accessing camera:", error)
      alert("No se pudo acceder a la cámara. Por favor, verifica los permisos.")
    }
  }

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement("canvas")
      canvas.width = videoRef.current.videoWidth
      canvas.height = videoRef.current.videoHeight
      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0)
        const base64Image = canvas.toDataURL("image/jpeg")
        setImage(base64Image)
        setMotorcycleInfo(null)
        setShowPrice(false)
        closeCamera()
      }
    }
  }

  const closeCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    setIsCameraOpen(false)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const file = e.dataTransfer.files?.[0]
    if (file && file.type.startsWith("image/")) {
      handleImageUpload(file)
    }
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Bike className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Mortalika</h1>
              <p className="text-sm text-muted-foreground">Identificador de Motos y Productos</p>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Upload Section */}
          <div className="space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-balance text-foreground mb-2">Identifica tu motocicleta</h2>
              <p className="text-muted-foreground text-lg">
                Sube una imagen y descubre toda la información de tu moto y sus productos
              </p>
            </div>

            {isCameraOpen && (
              <Card className="overflow-hidden">
                <div className="relative">
                  <video ref={videoRef} autoPlay playsInline className="w-full h-64 object-cover" />
                  <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
                    <Button onClick={capturePhoto} size="lg">
                      <Camera className="w-5 h-5 mr-2" />
                      Capturar
                    </Button>
                    <Button onClick={closeCamera} variant="outline" size="lg">
                      Cancelar
                    </Button>
                  </div>
                </div>
              </Card>
            )}

            {!isCameraOpen && (
              <Card
                className={`relative border-2 border-dashed transition-all duration-300 ${
                  isDragging ? "border-primary bg-primary/5 scale-[1.02]" : "border-border hover:border-primary/50"
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <div className="p-8 sm:p-12">
                  {!image ? (
                    <div className="flex flex-col items-center justify-center text-center space-y-4">
                      <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center">
                        <Upload className="w-10 h-10 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-foreground mb-2">Arrastra tu imagen aquí</h3>
                        <p className="text-muted-foreground">o haz clic para seleccionar un archivo</p>
                      </div>
                      <div className="flex gap-3">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileChange}
                          className="hidden"
                          id="file-upload"
                        />
                        <label htmlFor="file-upload">
                          <Button asChild size="lg" className="cursor-pointer">
                            <span>Seleccionar imagen</span>
                          </Button>
                        </label>
                        <Button onClick={openCamera} variant="outline" size="lg">
                          <Camera className="w-5 h-5 mr-2" />
                          Abrir cámara
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <img
                        src={image || "/placeholder.svg"}
                        alt="Moto subida"
                        className="w-full h-64 object-cover rounded-lg"
                      />
                      <div className="flex gap-2">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileChange}
                          className="hidden"
                          id="file-upload-2"
                        />
                        <label htmlFor="file-upload-2" className="flex-1">
                          <Button variant="outline" className="w-full cursor-pointer bg-transparent" asChild>
                            <span>Cambiar imagen</span>
                          </Button>
                        </label>
                        <Button onClick={openCamera} variant="outline">
                          <Camera className="w-5 h-5" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            )}

            {image && !motorcycleInfo && !isAnalyzing && !isCameraOpen && (
              <Button onClick={() => analyzeImage(image)} size="lg" className="w-full">
                <Bike className="w-5 h-5 mr-2" />
                Identificar motocicleta
              </Button>
            )}

            {isAnalyzing && (
              <div className="flex items-center justify-center gap-3 p-6 bg-card rounded-lg border border-border">
                <Loader2 className="w-5 h-5 animate-spin text-primary" />
                <span className="text-foreground font-medium">Analizando motocicleta...</span>
              </div>
            )}
          </div>

          {/* Results Section */}
          {motorcycleInfo && !isAnalyzing && (
            <div className="space-y-6">
              <Card className="overflow-hidden border-primary/20">
                <div className="bg-gradient-to-br from-primary/10 to-primary/5 p-6 border-b border-border">
                  <h3 className="text-2xl font-bold text-foreground mb-1">{motorcycleInfo.name}</h3>
                  <p className="text-muted-foreground">Identificación completada</p>
                </div>

                <div className="p-6 space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground font-medium">Marca</p>
                      <p className="text-lg font-semibold text-foreground">{motorcycleInfo.brand}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground font-medium">Modelo</p>
                      <p className="text-lg font-semibold text-foreground">{motorcycleInfo.model}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground font-medium">Año</p>
                      <p className="text-lg font-semibold text-foreground">{motorcycleInfo.year}</p>
                    </div>
                  </div>

                  <div className="space-y-2 pt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground font-medium">Descripción</p>
                    <p className="text-foreground leading-relaxed">{motorcycleInfo.description}</p>
                  </div>

                  {!showPrice ? (
                    <Button onClick={() => setShowPrice(true)} size="lg" className="w-full">
                      <DollarSign className="w-5 h-5 mr-2" />
                      Ver precio
                    </Button>
                  ) : (
                    <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 text-center">
                      <p className="text-sm text-muted-foreground mb-2">Precio aproximado</p>
                      <p className="text-4xl font-bold text-primary">{motorcycleInfo.price}</p>
                      <p className="text-xs text-muted-foreground mt-2">*Precio estimado basado en el mercado actual</p>
                    </div>
                  )}
                </div>
              </Card>

              {/* Products Section */}
              {motorcycleInfo.products && motorcycleInfo.products.length > 0 && (
                <Card className="overflow-hidden">
                  <div className="bg-gradient-to-br from-secondary/10 to-secondary/5 p-6 border-b border-border">
                    <div className="flex items-center gap-2">
                      <Package className="w-5 h-5 text-primary" />
                      <h3 className="text-xl font-bold text-foreground">Productos Relacionados</h3>
                    </div>
                  </div>
                  <div className="p-6 space-y-4">
                    {motorcycleInfo.products.map((product, index) => (
                      <div key={index} className="p-4 bg-secondary/20 rounded-lg border border-border space-y-2">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 space-y-1">
                            <h4 className="font-semibold text-foreground">{product.name}</h4>
                            <p className="text-sm text-muted-foreground">{product.description}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-primary">{product.price}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
